// const express = require("express")
// //import express from express
// const useeSchema = require("./myfile.js")
// const app = express()
// const router = express.Router()
// const {createData,getData} = require("./controller.js")
// router.get('/getData', getData)
// router.post('/', createData)
// export default router;
const Data = require('./myfile.js')
const express = require('express')
const router = express.Router()

router.post("/add", async (req, res) => {
  return res.send("success")
  const newData = new Data({

    name: req.body.name,
    phone: req.body.phone
    })
    // const newData = new Data(req.body);
  
    // try {
    //   await Data.save();
    //   response.send(newData);
    // } catch (error) {
    //   response.status(500).send(error);
    // }
});
module.exports=router
