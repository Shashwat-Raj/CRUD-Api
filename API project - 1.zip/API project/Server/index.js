
var express=require('express')
var app=express()
const mongoose=require("mongoose")
const cors=require("cors")
//import router from './routes.js';
const routes = require("./routes.js")
const bodyParser = require("body-parser")
app.use(bodyParser.json())
app.use('/route',routes)
//const port = 3000

app.get('/', (req, res) => {
  res.send('This is Shashwat and creating my CRUD api ')
})
app.use(cors())

// app.listen(port, () => {
//   console.log(`Example app listening at http://localhost:${port}`)
// }
// )
mongoose.connect("mongodb+srv://shashwat:Ddr4ssd5835@cluster0.5kyq4.mongodb.net/myFirstDatabase?retryWrites=true&w=majority",{ useNewUrlParser:true, useUnifiedTopology:true})
.then(() => app.listen(5000, ()=> {console.log("server running on port: 5000")})) 
.catch((error)=>console.log(error.message));