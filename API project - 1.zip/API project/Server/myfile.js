const mongoose = require("mongoose")
const dataSchema =new mongoose.Schema({
    name :{
        type: String, 
        Required: true
        },
    phone :{
        type: String, 
        Required: true
        },
    department :{
            type: String, 
            Required: true
            },
    email :{
                type: String, 
                Required: true
                }
})
// const Data=mongoose.model("Data", dataSchema)
// module.exports= Data;
module.exports = mongoose.model("Data", dataSchema)