// const express = require("express")
// const mongoose = require("mongoose")
// const Data = require("./myfile.js")
// export const createData = async(req, res) =>{

//     const post = req.body;
//     const newEntry = new Data(post)
    
//     try{
//     await newEntry.save();
//     res.status(201).json(newEntry);
//         } catch (error) {
//             res.status(409).json({message:error.message});
//         }
//     }
//     export const getData = async(req, res) =>{

//         try{
//         const viewData = await Data.find();
        
//             } catch (error) {
//                 res.status(409).json({message:error.message});
//             }
//         }
        
//         }